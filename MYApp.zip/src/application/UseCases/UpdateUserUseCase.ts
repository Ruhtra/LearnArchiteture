// src/application/use-cases/UpdateUserUseCase.ts
import { IUserRepository } from "../repositories/IUserRepository";
import { User } from "../../domain/entities/User";

interface UpdateUserRequest {
  userId: string;
  email?: string;
  passwordHash?: string;
  name?: string;
  birthDate?: Date;
  profilePicture?: string;
  address?: {
    street?: string;
    number?: string;
    postalCode?: string;
    city?: string;
    country?: string;
  };
  document?: {
    cpf?: string;
    rg?: string;
    otherInfo?: string;
  };
  phones?: {
    number?: string;
    isPrimary?: boolean;
  }[];
}

export class UpdateUserUseCase {
  constructor(private userRepository: IUserRepository) {}

  async execute(data: UpdateUserRequest): Promise<User | null> {
    const user = await this.userRepository.findById(data.userId);
    if (!user) throw new Error("User not found");

    return await this.userRepository.update(user);
  }
}
